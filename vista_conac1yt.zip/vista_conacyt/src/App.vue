<template>
  <v-app>

          <v-navigation-drawer v-model="drawer" app color="indigo-darken-4"> 
              <v-list dense >
                                    <v-img
                                src="@/assets/conacyt.png"
                                class="pa-4"
                                width="auto"
                                height="180" ></v-img>

                                  <!-- DASHBOARD-->
                                <v-list-item to="/dashboard" prepend-icon="mdi-view-dashboard">
                                              <v-list-item-content>
                                                        <v-list-item-title > Dashboard </v-list-item-title>
                                              </v-list-item-content>
                                </v-list-item>

                                  <!--ACTIVOS-->
                                  <v-list-item to="/activos" prepend-icon="mdi-finance">
                                    <v-list-item-content>
                                                <v-list-item-title> Activos </v-list-item-title>
                                      </v-list-item-content>
                                  </v-list-item>

                                  <!--USUARIOS (CON EL SUBMENÚ)-->
                                  <v-list-group
                                          prepend-icon="mdi-account-group"
                                           append-icon="mdi-chevron-down"
                                          value="false" >
                                    <!-- Activador del Grupo -->
                                    <template v-slot:activator="{props}">
                                      <v-list-item v-bind="props">
                                        <v-list-item-content>
                                          <v-list-item-title> Usuarios</v-list-item-title>
                                        </v-list-item-content>
                                      </v-list-item>
                                    </template>

                                    <!-- Ítems del Submenú -->
                                    <v-list-item to="/usuarios/gestion" prepend-icon="mdi-account-cog">
                                      <v-list-item-content>
                                        <v-list-item-title> Ver Usuarios</v-list-item-title>
                                      </v-list-item-content>
                                    </v-list-item>

                                    <v-list-item to="/usuarios/formulario" prepend-icon="mdi-account-plus-outline">
                                      <v-list-item-content>
                                        <v-list-item-title>Crear Usuarios</v-list-item-title>
                                      </v-list-item-content>
                                    </v-list-item>
                                  </v-list-group>


                                  <!--CONFIGURACIÓN-->
                                 <v-list-item to="/configuracion" prepend-icon="mdi-cog">
                                      <v-list-item-content>
                                                <v-list-item-title> Configuración </v-list-item-title>
                                      </v-list-item-content>
                                  </v-list-item>
                                  <!--CERRAR CESIÓN-->

                                  <v-list-item prepend-icon="mdi-logout">
                                          <v-list-content>
                                                     <v-list-item-title> Cerrar sesión</v-list-item-title>
                                          </v-list-content>
                                  </v-list-item>
            </v-list>
        </v-navigation-drawer>
                    <!--CERRANDO EL COMPONENTE APPBAR-->
                 <AppBar @toggle-drawer="drawer = !drawer" />
    <v-main>
      <router-view/>
    </v-main>
  </v-app>
</template>

<script>
import  AppBar from "@/components/AppBar.vue"; 

export default {
  name: 'App', 
  components: {
    AppBar,
  },
  data() {
      return {
          drawer: false,
      }
  }
}
</script>

<style>
.header-color {
  background-color: #2D3339 !important;
}
</style>
