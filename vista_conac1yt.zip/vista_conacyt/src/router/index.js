import { createRouter, createWebHistory } from 'vue-router'
import ActivosView from '@/views/ActivosView.vue'
import ConfiguracionView from '@/views/ConfiguracionView.vue'
import DashboardView from '@/views/DashboardView.vue'
import EmpleoView from '@/views/EmpleoView.vue'
import FormularioUsuarioView from '@/views/usuarios/FormularioUsuarioView.vue'
import GestionUsuariosView from '@/views/usuarios/GestionUsuariosView.vue'
import ReportesView from '@/views/ReportesView.vue'
import UsuariosBaseView from '@/views/usuarios/UsuariosBaseView.vue'


const routes = [
  {
    path: '/',
    name: 'home',
    component: EmpleoView
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: DashboardView
  },
  {
    path: '/activos',
    name: 'activos',
    component: ActivosView
  },
  {
    path: '/reportes',
    name: 'reportes',
    component: ReportesView
  }, 
  {
    path: '/usuarios',
    name: 'usuarios',
    component: UsuariosBaseView,
            children: [
                { path: 'gestion',
                  name:'GestionUsuarios',
                  component: GestionUsuariosView
                },
                { path: 'formulario',
                  name:'Formulario',
                  component: FormularioUsuarioView
                },
            ],
  },
  {
    path: '/configuracion',
    name: 'Configuracion',
    component: ConfiguracionView
  }
  
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
