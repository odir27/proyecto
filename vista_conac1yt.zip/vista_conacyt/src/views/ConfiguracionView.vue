<template>
    <div>
      <h1>Configuración</h1>
      <p>Bienvenido a configuración</p>
    </div>
  </template>
  
  <script>
export default {
    name: 'ConfiguracionView'
}
</script>