<template>
    <div>
      <h1>Usuarios</h1>
      <router-view />
    </div>
  </template>
  
  <script>
  export default {
    name: "UsuariosBaseView",
  };
  </script>
  