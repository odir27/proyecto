<template>
<v-container fluid>
          <h2 class="h-1">Panel de admistración de usuarios</h2>
              <br> 
                           <v-card> 
                                <v-card-text>              
                                  <v-table>
                                    <thead class="t-h">
                                          <tr > 
                                              <th>Código</th>
                                              <th>Nombre del usuario</th>
                                              <th>Apellido del usuario</th>
                                              <th>Correo</th>
                                              <th>Teléfono</th>
                                              <th>Opciones</th>
                                          </tr>
                                    </thead>
                                    <tbody>
                                            <tr v-for="(employee, i) in employees" :key="i" >
                                              <th> {{ employee.idemployee || 'N/A ' }}</th>
                                              <th> {{ employee.empfname }} </th>
                                              <th>{{ employee.empfsurname }} </th>
                                              <th> {{ employee.empemail }}</th>
                                              <th>{{ employee.empcell }} </th>
                                              <th> 
                                                <v-btn-group>
                                                <v-btn prepend-icon="mdi-account-details" color="indigo"   class="btn-t"
                                                 @click="infoUsuario(employee.idemployee,1)"> VER INFO</v-btn>
                                                <v-btn prepend-icon="mdi-account-edit" color="green" class="btn-t" 
                                                @click="infoUsuario(employee.idemployee,2)" >EDITAR INFO</v-btn>
                                                 <v-btn prepend-icon="mdi-account-off-outline" color="red"  class="btn-t" 
                                                @click="eliminarUsuario(employee.idemployee)"> ELIMINAR</v-btn>
                                                </v-btn-group>
                                              </th>
                                            </tr>
                                    </tbody>
                            </v-table>
                                </v-card-text>
                           </v-card>

                      <!-- CARGAR  VENTANA EMERGENTE PARA  VER LA INFORMACIÓN DEL USAURIO-->  
                        <v-dialog
                        v-model="dialogOne"
                        transition="dialog-top-transition"
                        width="1200px"
                        height="auto"
                        persistent> 
                                <v-card>
                                    <v-card-text > 
                                      <v-card-title class="title-card-dialog"> INFORMACIÓN DEL USUARIO</v-card-title>
                                        <v-row>
                                          <v-col>
                                              <v-list>
                                                <v-list-item prepend-icon="mdi-card-account-details-outline" 
                                                :title="datos.idemployee" subtitle="ID del usuario">
                                               </v-list-item> <br>
                                                <v-list-item prepend-icon="mdi-account-circle"
                                                 :title="datos.empfname" subtitle="Primer nombre del usuario"> 
                                                </v-list-item>    <br>
                                                <v-list-item prepend-icon="mdi-account-circle"
                                                 :title="datos.empsname" subtitle="Segundo nombre del usuario"> 
                                                </v-list-item> <br>
                                                <v-list-item prepend-icon="mdi-account-circle" 
                                                :title="datos.emptname" subtitle = "Tercer nombre del usuario"> 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-account-circle"
                                                :title="datos.empfsurname" subtitle = "Apellido del usuario"> 
                                               </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-account-circle"
                                                :title="datos.empssurname" subtitle = "Apellido del usuario"> 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-account-circle"
                                                :title="datos.emptsurname" subtitle = "Tercer apellido del usuario"> 
                                               </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-account"
                                                :title="datos.empmname" subtitle = "Nombre medio del usuario"> 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-card-account-details-outline"
                                                :title="datos.empdui" subtitle = "DUI del usuario">
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-card-account-details"
                                                :title="datos.empnit" subtitle = "NIT del usuario"> 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-calendar-month-outline"
                                                :title="datos.empborndate" subtitle = "Fecha de nacimiento"> 
                                                </v-list-item>
                                                </v-list>
                                          </v-col>
                                            <!---->
                                            <v-col>
                                               <v-list>
                                                <v-list-item prepend-icon="mdi-email-outline" 
                                                :title="datos.empemail" subtitle = "Fecha de nacimiento"> 
                                                </v-list-item> <br>
                                                <v-list-item prepend-icon="mdi-phone"  
                                                :title="datos.empcell" subtitle = "Fecha de nacimiento"> 
                                                </v-list-item>  <br>   
                                                 <v-list-item prepend-icon="mdi-phone-classic" 
                                                 :title="datos.empoftel" subtitle = "Número de teléfono de la oficina"> 
                                                </v-list-item> <br>
                                                <v-list-item prepend-icon="mdi-account-details" 
                                                :title="datos.empecontactname" subtitle = "Nombre del contacto de emergencia" >
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-phone-alert"
                                                 :title="datos.empecontactcel" subtitle = "Número del contacto de emergencia"> 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-home-heart"
                                                :title="datos.empcontactkin" subtitle = "Parentesco"> 
                                                </v-list-item> <br>
                                                <v-list-item prepend-icon="mdi-gender-male-female"
                                                :title="datos.empbgender" subtitle="Género del usuario"> 
                                                </v-list-item> <br>
                                                <v-list-item prepend-icon="mdi-account-circle"
                                                :title="datos.empfullname" subtitle="Nombre completo del usuario"> 
                                                </v-list-item> <br>
                                               <v-list-item prepend-icon="mdi-account-circle"
                                                :title="datos.empfullnameb" subtitle = "Nombre alternativo del usuario"> 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-briefcase"
                                                :title="datos.emp_idposition" subtitle = "Cargo del usuario" > 
                                                </v-list-item><br>
                                                <v-list-item prepend-icon="mdi-badge-account-alert-outline"
                                                :title="datos.emp_e" subtitle = "Estado del usuario" > 
                                                </v-list-item>
                                               </v-list>
                                            </v-col>
                                        </v-row>
                                        <v-row>
                                            <v-col>
                                              <v-btn @click="dialogOne=false" color="rgb(58, 58, 161)"
                                               block>   CERRAR</v-btn>
                                          </v-col>
                                      </v-row>
                                  </v-card-text>
                               </v-card>
                          </v-dialog>

                          <!-- VENTANA DEL FORMULARIO PARA ACTUALIZAR LA INFORMACIÓN DEL USUARIO-->
                           <v-dialog
                           v-model="dialogTwo"
                           transition="dialog-top-transition"
                           width="1200px"
                           height="auto"
                           persistent>
                                <v-card>
                                  <v-card-title  class="title-card-dialog"   > FORMULARIO PARA EDITAR LA INFORMACIÓN DEL USUARIO</v-card-title>
                                      <v-card-text>
                                            <v-row>
                                                <v-col >
                                      <v-text-field
                                      label="Nombre del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el primer nombre del usuario" 
                                      v-model="datos.empfname">
                                      </v-text-field>
                            </v-col>
                            <v-col>
                                      <v-text-field
                                      label="Segundo nombre del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el segundo nombre del usuario"
                                      v-model="datos.empsname" >
                                      </v-text-field>
                            </v-col>
                            <v-col >
                                      <v-text-field
                                      label="Tercer nombre del usuario"
                                      type="text"
                                      maxLength="70" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el tecer nombre del usuario" 
                                      v-model="datos.emptname">
                                      </v-text-field>
                            </v-col>
                        </v-row>
                        <br>
                              <!--APELLIDOS-->
                        <v-row>
                          <v-col>
                                      <v-text-field
                                      label="Apellido del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el primer nombre del usuario"
                                      v-model="datos.empfsurname" >
                                      </v-text-field>
                            </v-col>
                            <v-col >
                                      <v-text-field
                                      label="Segundo apellido del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el segundo nombre del usuario" 
                                      v-model="datos.empssurname" >
                                      
                                      </v-text-field>
                            </v-col>
                            <v-col >
                                      <v-text-field
                                      label="Tercer apellido del usuario"
                                      type="text"
                                      maxLength="70" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el tecer nombre del usuario" 
                                      v-model="datos.emptsurname" >
                                      </v-text-field>
                            </v-col>
                        </v-row>
                        <!-- -->
                        <v-row>
                              <v-col >
                                          <v-text-field
                                          label="Nombre medio del usuario"
                                          type="text"
                                          maxLength="70" 
                                          counter
                                          clearable
                                          prepend-icon="mdi-account"
                                          color="indigo-darken-1"
                                          placeholder="Coloque el nombre medio del usuario" 
                                          v-model="datos.empmname" >
                                          </v-text-field>
                                </v-col>                              
                                <v-col >
                                          <v-text-field
                                          label="DUI del usuario"
                                          type="number"
                                          maxLength="10" 
                                          counter
                                          clearable
                                          prepend-icon="mdi-card-account-details-outline"
                                          color="indigo-darken-1"
                                          placeholder="Coloque el número de DUI sin guiones"
                                          :rules = [rules.numeric]
                                          v-model="datos.empdui" >
                                          </v-text-field>
                                </v-col>
                        </v-row>
                        <v-row>
                            <v-col >
                                            <v-text-field
                                              label="NIT del usuario"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-card-account-details"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de NIT sin guiones" 
                                              :rules = [rules.numeric]
                                              v-model="datos.empnit" >
                                            </v-text-field>
                                  </v-col>
                                  <v-col >
                                            <v-text-field
                                              label="Fecha de nacimiento"
                                              type="date"
                                              clearable
                                              prepend-icon="mdi-calendar-month-outline"
                                              color="indigo-darken-1"
                                              v-model="datos.empborndate">
                                            </v-text-field>
                                  </v-col>
                        </v-row>
                        <v-row>
                              <v-col>
                                          <v-text-field
                                              label="Correo electrónico del usuario"
                                              type="email"
                                              maxLength="170"
                                              clearable
                                              counter
                                              prepend-icon="mdi-email-outline"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el email del usuario"
                                              v-model="datos.empemail" >
                                            </v-text-field>
                              </v-col>
                        </v-row>
                        <v-row>
                              <v-col>
                                            <v-text-field
                                              label="Teléfono personal del usuario"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-phone"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de teléfono del usuario" 
                                              :rules = [rules.numeric]
                                              v-model="datos.empcell" >
                                            </v-text-field>
                                </v-col>
                                <v-col>
                                            <v-text-field
                                              label="Número de teléfono de la oficina"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-phone-classic"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de teléfono de la oficina" 
                                              :rules = [rules.numeric]
                                              v-model="datos.empoftel">
                                            </v-text-field>
                                    </v-col>
                        </v-row>
                        <v-row>
                          <v-col>
                                         <v-text-field
                                            label="Nombre del contacto de emergencia"
                                            type="text"
                                            maxLength="70" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-account-details"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el nombre del contacto del usuario" 
                                            v-model="datos.empecontactname" >
                                          </v-text-field>
                                    </v-col>
                        </v-row>
                        <v-row>
                                    <v-col>
                                           <v-text-field
                                              label="Número del contacto de emergencia"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-phone-alert"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de teléfono de contacto del usuario" 
                                              :rules = [rules.numeric]
                                              v-model="datos.empecontactcel">
                                            </v-text-field>
                                    </v-col>
                                    <v-col>
                                           <v-text-field
                                           label="Parentesco"
                                            type="text"
                                            maxLength="70" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-home-heart"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el parentesco de la persona con el usuario"               
                                            v-model="datos.empcontactkin" >
                                            </v-text-field>
                                    </v-col>
                        </v-row>
                        <v-row>
                          <v-col >
                            <v-select
                                      label="Género del usuario"
                                     :items="generoOpciones"
                                     item-title="nombre"
                                     item-value="valor"
                                      clearable
                                      prepend-icon="mdi-gender-male-female"
                                      color="indigo-darken-1"
                                      v-model="datos.empbgender" >
                                      </v-select>
                          </v-col>
                          <v-col>
                            <v-text-field
                                            label="Nombre completo del usuario"
                                            type="text"
                                            maxLength="250" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-account"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el nombre completo del usuario" 
                                            v-model="datos.empfullname" >
                                          </v-text-field>
                          </v-col>
                          <v-col>
                                      <v-text-field
                                            label="Nombre alternativo del usuario"
                                            type="text"
                                            maxLength="250" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-account"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el nombre alternativo del usuario" 
                                            v-model="datos.empfullnameb" >
                                          </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                              <v-col >
                                <v-select
                                              label="Cargo del usuario"
                                              :items="cargoUsuarios"
                                              item-title="nombre"
                                              item-value="valor"
                                              clearable
                                              prepend-icon="mdi-briefcase"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el cargo del usuario" 
                                              v-model="datos.emp_idposition">
                                           </v-select>
                              </v-col>
                              <v-col>
                                <v-select
                                      label="Estado del usuario"
                                      :items="estadOpciones"
                                      item-title = "nombre"
                                      item-value="valor"
                                      clearable
                                      prepend-icon="mdi-badge-account-alert-outline"
                                      color="indigo-darken-1"
                                       v-model="datos.emp_e" >
                                </v-select>
                              </v-col>
                        </v-row>
                             <v-row>
                                <v-col class="d-flex justify-end">
                                  <v-btn class="ma-2 pa-2" color="warning" prepend-icon="mdi-cancel" @click="dialogTwo=false">
                                        CANCELAR
                                      </v-btn>
                                  <v-btn class="ma-2 pa-2"  color="success" @click="actualizarUsuario(datos.idemployee)">
                                    ACTUALIZAR DATOS
                                  </v-btn>
                                </v-col>
                             </v-row>
                                      </v-card-text>
                                </v-card>
                           </v-dialog>
</v-container>
  </template>
    <script>
    import Swal from 'sweetalert2'
    import axios from 'axios'

    export default {
        name: 'GestionUsuariosView',
        data() {
            return {
              employees: [],
              datos: {},
              dialogOne : false,
              dialogTwo: false,
              rules: {
                  numeric: value => (value >= 0 && /^\d+$/.test(value)) || 'El campo solo puede contener números mayores a 0 y no debe de tener guiones',
              },
              generoOpciones: [
              {nombre: 'Masculino', valor: 'M'},
              {nombre: 'Femenino', valor: 'F'},
              {nombre: 'Otro', valor: 'O'},
            ],
              cargoUsuarios: [
              { nombre: 'Presidente', valor: 1 },
              { nombre: 'Director/Directora Ejecutivo/Ejecutiva', valor: 2 },
              { nombre: 'Coordinador/Coordinadora del Observatorio Nacional de Ciencia y Tecnología', valor: 3 },
              { nombre: 'Jefe del Departamento de Fomento y Estímulos para la ICT', valor: 4 },
              { nombre: 'Jefe USEFI', valor: 5 },
              { nombre: 'Jefe de Unidad de Tecnologías de Información', valor: 6 },
              { nombre: 'Jefe del Departamento Cooperación y Gestión de Proyectos', valor: 7 },
              { nombre: 'Jefe de la Unidad de Protocolo y Relaciones Institucionales', valor: 8 },
              { nombre: 'Oficial de Información', valor: 9 },
              { nombre: 'Coordinador/Coordinadora del Departamento de Desarrollo Humano', valor: 10 },
              { nombre: 'Técnico de Presupuesto', valor: 11 },
              { nombre: 'Tesorero/Tesorera Institucional', valor: 12 },
              { nombre: 'Contador/Contadora Institucional', valor: 13 },
              { nombre: 'Técnico Especialista de Fomento y Estímulos para la ICT', valor: 14 },
              { nombre: 'Motorista', valor: 15 }
            ],
              estadOpciones: [
              { nombre: 'Activo', valor: 'A' },
              { nombre: 'Inactivo', valor: 'I' },
              { nombre: 'Retirado', valor: 'R' },
              { nombre: 'Eliminado', valor: 'E' },
              { nombre: 'Suspendido', valor: 'S' },
              { nombre: 'Contingente', valor: 'C' }
            ]
            }
        },
        methods: {
            obtEmployees() {
              this.employees = []
                      axios.get('http://127.0.0.1:8000/api/employee/select') 
                      .then (
                          response => {
                                if (response.data.code == 200)  {
                                        let res = response.data;
                                        this.employees = res.data;
                                }
                          }
                      )
                .catch (error =>console.log ('Ha ocurrido un error' + error));
            },
             infoUsuario(idemployee,action) {
                  if(action == 1) {
                        this.dialogOne = true;
                  } 
                  else {
                        this.dialogTwo = true;
                  }
                    axios.get(`http://127.0.0.1:8000/api/employee/find/${idemployee}`) 
                    .then(
                        response => {
                            if (response.data.code == 200)  {
                                let res = response.data;
                                this.datos = res.data;
                            }
                        }
                    )
                    .catch( (error) => {
                        console.error('Error al cancelar el formulario:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: 'Ocurrió un problema al intentar esta acción.',
                        });
    });
            },
            actualizarUsuario(idemployee) {
                    axios.put(`http://127.0.0.1:8000/api/employee/update/${idemployee}`,this.datos)
                    .then(
                         response => {
                              if(response.data.code == 200 ){
                                  Swal.fire({
                                              icon: 'success',
                                              title: '¡Los datos han sido modificados!',
                                              allowOutsideClick: false,  //Bloque los clicks que el usaurio pueda dar fuera de la alerta
                                              confirmButtonText: 'CERRAR',
                                              confirmButtonColor: '#93ff26',
                                              text: response.data.data
                                        } );
                                              this.dialogTwo = false;
                                              this.obtEmployees();
                              }
                         }
                    )
                    .catch( (error) => {
                        console.error('Error al cancelar el formulario:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            showConfirmButton: 'CERRAR',
                            allowOutsideClick: false,  //Bloque los clicks que el usaurio pueda dar fuera de la alerta
                            text: 'Ocurrió un problema al intentar esta acción',
                        });
                    });
            },  
            eliminarUsuario(idemployee) {
                  Swal.fire({
                          icon: 'warning',
                          title: '¿Estás seguro de realizar esta acción?',
                          text: 'El usuario y su información se eliminará permanentemente de la base de datos.',
                          showCancelButton: true,
                          allowOutsideClick: false,  //Bloque los clicks que el usaurio pueda dar fuera de la alerta
                          cancelButtonText: 'No, prefiero cancelar',
                          cancelButtonColor: '#a2b8ff',
                          confirmButtonColor: '#ff8a8a',
                          confirmButtonText: 'Sí, quiero realizar la acción'
                  })
                .then(
                    (result) => {
                      if(result.isConfirmed) {
                          axios.delete(`http://127.0.0.1:8000/api/employee/delete/${idemployee}`)
                          .then (
                              response => {
                                    if (response.data.code == 200)  {
                                        Swal.fire( {
                                                          icon: 'success',
                                                          title:  '¡ACCIÓN REALIZADA!',                
                                                          allowOutsideClick: false,
                                                          confirmButtonText: 'CERRAR',
                                                          confirmButtonColor: '#93ff26',
                                                          text:  response.data.data,
                                                          
                                        } );
                                                 this.obtEmployees()
                                    }
                              }
                          )
                    }               
                    }
                )
                .catch( (error) => {
                        console.error('Error al cancelar el formulario:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            showConfirmButton: 'CERRAR',
                            text: 'Ocurrió un problema al intentar esta acción',
                        });
                    });         
            }
        },
        created() {
            this.obtEmployees()
        }
    }
    </script>

    <style > 
    .no-users {
  text-align: center;
  font-size: 18px;
  color: gray;
  margin-top: 20px;
}
    .h-1 {
      text-align: center;
      background-color: rgb(58, 58, 161);
      color: white;
      padding: 8px;
    }
    .t-h {
      background-color: rgb(196, 212, 255);
    }
    .btn-t {
      margin-right: 10px;
      margin-top: 5px;
    }
 
 .title-card-dialog{
  text-align: center;
  background-color:  rgb(58, 58, 161);
  color: white;
 }
    </style> 