<template>
    <v-container fluid >
      <h2 class="h-1">Formulario para crear un nuevo usuario</h2>
            <v-form   ref="form" v-model="valid" >
                        <br>
                            <v-row xs sm md  lg xl xxl>
                            <v-col >
                                      <v-text-field
                                      label="Nombre del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el primer nombre del usuario" 
                                      :rules="[rules.required]"
                                      v-model="employee.empfname">
                                      </v-text-field>
                            </v-col>
                            <v-col>
                                      <v-text-field
                                      label="Segundo nombre del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el segundo nombre del usuario"
                                      outlined
                                      v-model="employee.empsname" >
                                      </v-text-field>
                            </v-col>
                            <v-col >
                                      <v-text-field
                                      label="Tercer nombre del usuario"
                                      type="text"
                                      maxLength="70" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el tecer nombre del usuario" 
                                      v-model="employee.emptname">
                                      </v-text-field>
                            </v-col>
                        </v-row>
                        <br>
                              <!--APELLIDOS-->
                        <v-row>
                          <v-col>
                                      <v-text-field
                                      label="Apellido del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el primer nombre del usuario"
                                       :rules="[rules.required]"
                                      v-model="employee.empfsurname" >
                                      </v-text-field>
                            </v-col>
                            <v-col >
                                      <v-text-field
                                      label="Segundo apellido del usuario"
                                      type="text"
                                      maxLength="45" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el segundo nombre del usuario" 
                                      v-model="employee.empssurname" >
                                      
                                      </v-text-field>
                            </v-col>
                            <v-col >
                                      <v-text-field
                                      label="Tercer apellido del usuario"
                                      type="text"
                                      maxLength="70" 
                                      counter
                                      clearable
                                      prepend-icon="mdi-account-circle"
                                      color="indigo-darken-1"
                                      placeholder="Coloque el tecer nombre del usuario" 
                                      v-model="employee.emptsurname" >
                                      </v-text-field>
                            </v-col>
                        </v-row>
                        <!-- -->
                        <v-row>
                              <v-col >
                                          <v-text-field
                                          label="Nombre medio del usuario"
                                          type="text"
                                          maxLength="70" 
                                          counter
                                          clearable
                                          prepend-icon="mdi-account"
                                          color="indigo-darken-1"
                                          placeholder="Coloque el nombre medio del usuario" 
                                          v-model="employee.empmname" >
                                          </v-text-field>
                                </v-col>                              
                                <v-col >
                                          <v-text-field
                                          label="DUI del usuario"
                                          type="number"
                                          maxLength="10" 
                                          counter
                                          clearable
                                          prepend-icon="mdi-card-account-details-outline"
                                          color="indigo-darken-1"
                                          placeholder="Coloque el número de DUI sin guiones."
                                          :rules="[rules.range]"
                                          v-model="employee.empdui" >
                                          </v-text-field>
                                </v-col>
                        </v-row>
                        <v-row>
                            <v-col >
                                            <v-text-field
                                              label="NIT del usuario"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-card-account-details"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de NIT sin guiones." 
                                              :rules="[rules.range]"
                                              v-model="employee.empnit" >
                                            </v-text-field>
                                  </v-col>
                                  <v-col >
                                            <v-text-field
                                              label="Fecha de nacimiento"
                                              type="date"
                                              clearable
                                              prepend-icon="mdi-calendar-month-outline"
                                              color="indigo-darken-1"
                                              :rules="[rules.required]" 
                                              v-model="employee.empborndate">
                                            </v-text-field>
                                  </v-col>
                        </v-row>
                        <v-row>
                              <v-col>
                                          <v-text-field
                                              label="Correo electrónico del usuario"
                                              type="email"
                                              maxLength="170"
                                              clearable
                                              counter
                                              prepend-icon="mdi-email-outline"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el email del usuario"
                                              :rules="[rules.required, rules.email]"
                                              v-model="employee.empemail" >
                                            </v-text-field>
                              </v-col>
                        </v-row>
                        <v-row>
                              <v-col>
                                            <v-text-field
                                              label="Teléfono personal del usuario"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-phone"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de teléfono del usuario" 
                                              :rules="[rules.range]"
                                              v-model="employee.empcell" >
                                            </v-text-field>
                                </v-col>
                                <v-col>
                                            <v-text-field
                                              label="Número de teléfono de la oficina"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-phone-classic"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de teléfono de la oficina" 
                                              :rules="[rules.range]"
                                              v-model="employee.empoftel">
                                            </v-text-field>
                                    </v-col>
                        </v-row>
                        <v-row>
                          <v-col>
                                         <v-text-field
                                            label="Nombre del contacto de emergencia"
                                            type="text"
                                            maxLength="70" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-account-details"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el nombre del contacto del usuario" 
                                            :rules="[rules.required]"
                                            v-model="employee.empecontactname" >
                                          </v-text-field>
                                    </v-col>
                        </v-row>
                        <v-row>
                                    <v-col>
                                           <v-text-field
                                              label="Número del contacto de emergencia"
                                              type="number"
                                              maxLength="17" 
                                              counter
                                              clearable
                                              prepend-icon="mdi-phone-alert"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el número de teléfono de contacto del usuario" 
                                              :rules="[ rules.range]" 
                                              v-model="employee.empecontactcel">
                                            </v-text-field>
                                    </v-col>
                                    <v-col>
                                           <v-text-field
                                           label="Parentesco"
                                            type="text"
                                            maxLength="70" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-home-heart"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el parentesco de la persona con el usuario"                  
                                            :rules="[rules.required]"
                                            v-model="employee.empcontactkin" >
                                            </v-text-field>
                                    </v-col>
                        </v-row>
                        <v-row>
                          <v-col >
                                      <v-select
                                      label="Género del usuario"
                                     :items="generoOpciones"
                                     item-title="nombre"
                                     item-value="valor"
                                      clearable
                                      prepend-icon="mdi-gender-male-female"
                                      color="indigo-darken-1"
                                      :rules="[rules.required]" 
                                      v-model="employee.empbgender" >
                                      </v-select>
                          </v-col>
                          <v-col>
                            <v-text-field
                                            label="Nombre completo del usuario"
                                            type="text"
                                            maxLength="250" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-account"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el nombre completo del usuario" 
                                            :rules="[rules.required]"
                                            v-model="employee.empfullname" >
                                          </v-text-field>
                          </v-col>
                          <v-col>
                                      <v-text-field
                                            label="Nombre alternativo del usuario"
                                            type="text"
                                            maxLength="250" 
                                            counter
                                            clearable
                                            prepend-icon="mdi-account"
                                            color="indigo-darken-1"
                                            placeholder="Coloque el nombre alternativo del usuario" 
                                            :rules="[rules.required]"
                                            v-model="employee.empfullnameb" >
                                          </v-text-field>
                          </v-col>
                        </v-row>
                        <v-row>
                              <v-col >
                                           <v-select
                                              label="Cargo del usuario"
                                              :items="cargoUsuarios"
                                              item-title="nombre"
                                              item-value="valor"
                                              clearable
                                              prepend-icon="mdi-briefcase"
                                              color="indigo-darken-1"
                                              placeholder="Coloque el cargo del usuario" 
                                              :rules="[rules.required]" 
                                              v-model="employee.emp_idposition">
                                           </v-select>
                              </v-col>
                              <v-col>
                                <v-select
                                      label="Estado del usuario"
                                      :items="estadOpciones"
                                      item-title = "nombre"
                                      item-value="valor"
                                      clearable
                                      prepend-icon="mdi-badge-account-alert-outline"
                                      color="indigo-darken-1"
                                       :rules="[rules.required]"
                                       v-model="employee.emp_e" >
                                </v-select>
                              </v-col>
                        </v-row>
                             <v-row>
                                <v-col class="d-flex justify-end">
                                  <v-btn class="ma-2 pa-2"  color="warning" @click="cancelarFormulario" prepend-icon="mdi-cancel">
                                    REINICIAR FORMULARIO
                                  </v-btn>
                                  <v-btn class="ma-2 pa-2"  color="success" @click="agregarUsuario" prepend-icon="mdi-account-plus">
                                    AGREGAR USUARIO
                                  </v-btn>
                                </v-col>
                             </v-row>
            </v-form>
    </v-container>
  </template>
    <script>
    import axios  from 'axios';
    import Swal from 'sweetalert2'

    export default {
        name: 'FormularioUsuarioView',
        data() {
          return {
            valid : false,
            employee : { empfname: '',
                                empsname: null,
                                emptname: null,
                                empfsurname: '',
                                empssurname: null,
                                emptsurname: null,
                                empmname: null,
                                empdui: '',
                                empnit: '',
                                empborndate: '',
                                empemail: '',
                                empcell: '',
                                empoftel: '',
                                empecontactname: '',
                                empecontactcel: '',
                                empcontactkin: '',
                                empbgender: '',
                                empfullname: '',
                                empfullnameb: '',
                                emp_idposition: '',
                                emp_e: ''},
            rules: { 
              required: value => !! value || 'Este campo es obligatorio.',
              email: value => /.+@.+\..+/.test(value) || 'Este campo es obligatorio y debe ser un correo eléctrónico válido',
              range: value => (value >= 0 && /^\d+$/.test(value) ) || 'El campo es obligatorio y no se permite usar guiones ni números menores a 0',
            }, 
            generoOpciones: [
              {nombre: 'Masculino', valor: 'M'},
              {nombre: 'Femenino', valor: 'F'},
              {nombre: 'Otro', valor: 'O'},
            ],
            cargoUsuarios: [
              { nombre: 'Presidente', valor: 1 },
              { nombre: 'Director/Directora Ejecutivo/Ejecutiva', valor: 2 },
              { nombre: 'Coordinador/Coordinadora del Observatorio Nacional de Ciencia y Tecnología', valor: 3 },
              { nombre: 'Jefe del Departamento de Fomento y Estímulos para la ICT', valor: 4 },
              { nombre: 'Jefe USEFI', valor: 5 },
              { nombre: 'Jefe de Unidad de Tecnologías de Información', valor: 6 },
              { nombre: 'Jefe del Departamento Cooperación y Gestión de Proyectos', valor: 7 },
              { nombre: 'Jefe de la Unidad de Protocolo y Relaciones Institucionales', valor: 8 },
              { nombre: 'Oficial de Información', valor: 9 },
              { nombre: 'Coordinador/Coordinadora del Departamento de Desarrollo Humano', valor: 10 },
              { nombre: 'Técnico de Presupuesto', valor: 11 },
              { nombre: 'Tesorero/Tesorera Institucional', valor: 12 },
              { nombre: 'Contador/Contadora Institucional', valor: 13 },
              { nombre: 'Técnico Especialista de Fomento y Estímulos para la ICT', valor: 14 },
              { nombre: 'Motorista', valor: 15 }
            ],
            estadOpciones: [
              { nombre: 'Activo', valor: 'A' },
              { nombre: 'Inactivo', valor: 'I' },
              { nombre: 'Retirado', valor: 'R' },
              { nombre: 'Eliminado', valor: 'E' },
              { nombre: 'Suspendido', valor: 'S' },
              { nombre: 'Contingente', valor: 'C' }
            ]
          }
        },
        methods: {
          cancelarFormulario() {
              Swal.fire({
                  icon: 'warning',
                  title: '¿Estás seguro de que quieres reiniciardel formulario? Perderás todos los datos.',
                  showCancelButton: true,
                  allowOutsideClick: false,  //Bloque los clicks que el usaurio pueda dar fuera de la alerta
                  confirmButtonText: 'Sí, quiero reiniciar', 
                  cancelButtonText: 'No, quiero seguir editando',
                  cancelButtonColor: '#a2b8ff',
                  confirmButtonColor: '#ff8a8a',
    })
      .then((result) => {
                  if (result.isConfirmed) {
                                        this.employee = {
                                                                      empfname: '',
                                                                      empsname: null,
                                                                      emptname: null,
                                                                      empfsurname: '',
                                                                      empssurname: null,
                                                                      emptsurname: null,
                                                                      empmname: null,
                                                                      empdui: '',
                                                                      empnit: '',
                                                                      empborndate: '',
                                                                      empemail: '',
                                                                      empcell: '',
                                                                      empoftel: '',
                                                                      empecontactname: '',
                                                                      empecontactcel: '',
                                                                      empcontactkin: '',
                                                                      empbgender: '',
                                                                      empfullname: '',
                                                                      empfullnameb: '',
                                                                      emp_idposition: '',
                                                                      emp_e: ''};
                            this.$refs.form.resetValidation();
                            this.employee = { };
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Formulario reiniciado',
                                        confirmButtonText: 'CERRAR',
                                        confirmButtonColor: '#93ff26',
                                        text: 'Los datos del formulario han sido borrados correctamente.',
                                    });
        }
    })
    .catch( (error) => {
                        console.error('Error al cancelar el formulario:', error);
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            showConfirmButton: 'CERRAR',
                            text: 'Ocurrió un problema al intentar reiniciar el formulario.',
                        });
    });
   },
          agregarUsuario () {
                  if ( !this.valid ) { 
                    Swal.fire ({
                          icon: 'warning',
                          title: '¡Debes de completar los campos requeridos!',
                          confirmButtonText: 'CERRAR',
                          confirmButtonColor: '#3085d6',
                          text: 'Antes de registrar al nuevo usuario, asegurate de que los campos que son obligatorios estén completos.'
                    }) ;
                      return; }
                    axios.post('http://127.0.0.1:8000/api/employee/store', this.employee) 
                    .then ( 
                          response => {
                                  if (response.data.code == 200) {
                                      Swal.fire ({
                                          icon: 'success',
                                          title: '¡El usuario ha sido agregado. Ya puedes verlo en el panel principal!',
                                          confirmButtonText: 'CONFIRMAR',
                                          confirmButtonColor: '#93ff26',
                                          text: response.data.data
                                        })
                                        this.obtEmployees();
                                        this.employee = {};
                                  }
                          }
                    )
                    .catch(error => {
                              console.error('Error al enviar los datos:', error);                           
               });
              },
              obtEmployees()  {
                 axios.get('http://127.0.0.1:8000/api/employee/select') 
                  .then (
                    response => {
                                if (response.data.code == 200)  {
                                        let res = response.data;
                                        this.employee= res.data;                             
                                }
                          }
                  )
              }    
        },
        created() {
            this.obtEmployees();
        }        
    }
    </script>

    <style >
    .h-1{ 
      text-align: center;
      background-color: rgb(58, 58, 161);
      color: white;
      padding: 8px;
    }

.no-users {
  text-align: center;
  font-size: 18px;
  color: gray;
  margin-top: 20px;
}
  </style>