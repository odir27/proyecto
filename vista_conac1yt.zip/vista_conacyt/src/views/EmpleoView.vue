<template> 
    <v-container fluid >
            <h1 class="text-lg-center" style="color: darkblue;">GESTIÓN DE EMPLEADOS</h1>

            <v-card  color="grey-lighten-4">
                <v-card-text>   
                            <v-row>
                                <v-col >
                                    <v-text-field
                                    label="Nombre del empleo"
                                    type="text"
                                    maxLength="50"
                                    color="blue-darken-4"
                                    counter
                                    clearable
                                    prepend-icon="mdi-account-tie"
                                    placeholder="Ingrese el nombre del empleo a registrar" 
                                    v-model="empleo.nombre">
                                    </v-text-field>
                                    <br>
                                    <v-text-field
                                    label="Ubicación de la empresa"
                                    type="text"
                                    maxLength="50"
                                      color="blue-darken-4"
                                    counter
                                    clearable
                                    prepend-icon="mdi-map-marker"
                                    placeholder="Ingrese la ubicación de la empresa por favor" 
                                    v-model="empleo.ubicacion">
                                    </v-text-field>
                                    <br>
                                    <v-select
                                    label="Categoría del empleo"
                                    placeholder="Selecciona la categoría del empleo"
                                      color="blue-darken-4"
                                    :items="categorias"
                                    item-value="id"
                                    item-title="nombre"
                                    prepend-icon="mdi-briefcase"
                                    v-model="empleo.fk_categoria">
                                    </v-select>
                                    <br>
                                    <v-text-field
                                    label="Pago del empleo"
                                    type="number"
                                    maxLength="10"
                                      color="blue-darken-4"
                                    counter
                                    clearable
                                    prepend-icon="mdi-cash"
                                    placeholder="Ingrese el monto a pagar por el empleo" 
                                    v-model="empleo.pago">
                                    </v-text-field>
                                    <br>
                                    <v-text-field
                                    label="Tiempo de contrato"
                                    type="text"
                                    maxLength="100"
                                      color="blue-darken-4"
                                    counter
                                    clearable
                                    prepend-icon="mdi-clipboard-clock-outline"
                                    placeholder="Ingrese el tiempo de duración del contrato"
                                    v-model="empleo.tiempo_contrato">
                                    </v-text-field>
                                    <br>
                                    <v-text-field
                                    label="Horario laboral"
                                    type="text"
                                    maxLength="50"
                                      color="blue-darken-4"
                                    counter
                                    clearable
                                    prepend-icon="mdi-clock-outline"
                                    placeholder="Ingrese el horario establecido para el empleo" 
                                    v-model="empleo.horario">
                                    </v-text-field>
                                    <br>
                                    <v-textarea
                                    label="Descripción del empleo"
                                    type="text"
                                    maxLength="100"
                                      color="blue-darken-4"
                                    counter
                                    clearable
                                    prepend-icon=" mdi-text-box"
                                    placeholder="Describa adecuadamente en qué consiste el trabajo" 
                                    v-model="empleo.descripcion_empleo">
                                    </v-textarea>
                                    <br>
                                    <v-btn
                                    prepend-icon="mdi-account-plus"
                                    block 
                                    color="blue-darken-4"
                                    @click="agregarEmpleo">
                                        AGREGAR
                                    </v-btn>
                                </v-col>
                            </v-row>
                </v-card-text>
            </v-card>
            <br>
            <br>
                <v-card >
                    <v-card-text>
                            <v-row>
                                <v-col>
                                        <v-table>
                                            <thead style="background-color: rgb(13, 71, 161)" >
                                                        <tr style="color:white;">
                                                            <th class="text-lg-center">CÓDIGO</th>
                                                            <th class="text-lg-center">NOMBRE DEL EMPLEO</th>
                                                            <th class="text-lg-center">OPCIONES</th>
                                                        </tr>
                                            </thead>
                                                <tbody  >
                                                           <tr v-for="(empleo, i) in emples" :key="i">
                                                            <th class="text-lg-center"> {{empleo.id  }}</th>
                                                            <th class="text-lg-center">{{ empleo.nombre }}</th>
                                                            <th class="text-lg-center">
                                                                <v-btn-group>
                                                                                    <v-btn
                                                                                     icon="mdi-eye"
                                                                                     color="blue-darken-4" 
                                                                                    style="border-radius: 50px;
                                                                                    height: auto;
                                                                                    margin-right: 10px;"
                                                                                     @click="verEmpleo(empleo.id, 1)">  </v-btn>
                                                                                     <v-btn 
                                                                                     icon="mdi-pencil" 
                                                                                     color="green-darken-1"
                                                                                     style="border-radius: 50px;
                                                                                    height: auto;
                                                                                    margin-right: 10px"
                                                                                    @click="verEmpleo(empleo.id, 2)"
                                                                                     >  </v-btn>
                                                                                     <v-btn 
                                                                                     icon="mdi-delete" 
                                                                                     color="red-darken-4"
                                                                                      style="   border-radius:50px;
                                                                                    height: auto;"  
                                                                                    @click="borrarEmpleo(empleo.id)"></v-btn>
                                                                </v-btn-group>
                                                            </th>
                                                           </tr>
                                                </tbody>
                                        </v-table>
                                </v-col>
                            </v-row>
                    </v-card-text>
                </v-card>
    </v-container>
            <v-snackbar v-model="alertaEstado" color="success" timeout="2500">
                    {{ mensaje }}
            </v-snackbar>
               <v-dialog 
                v-model="dialogOne"
                transition="dialog-top-transition"
                width="600px">
                    <v-card title="Empleos" subtitle="Información del empleo">
                            <v-card-text   color="blue-darken-4">
                                        <v-list >
                                                <v-list-item prepend-icon="mdi-account-tie" :title="datos.nombre"></v-list-item>
                                                <v-list-item prepend-icon="mdi-map-marker" :title="datos.ubicacion"></v-list-item>
                                                <v-list-item prepend-icon="mdi-briefcase-outline" :title="datos.fk_categoria"></v-list-item>
                                                <v-list-item prepend-icon="mdi-cash" :title="datos.pago"></v-list-item>
                                                <v-list-item prepend-icon="mdi-clipboard-clock-outline" :title="datos.tiempo_contrato"></v-list-item>
                                                <v-list-item prepend-icon="mdi-clock-outline" :title="datos.horario"></v-list-item>
                                                <v-list-item prepend-icon=" mdi-text-box" :title="datos.descripcion_empleo"></v-list-item>
                                        </v-list>                                
                            </v-card-text>
                    </v-card>
                </v-dialog>
                <v-dialog
                v-model="dialogTwo"
                transition="dialog-top-transition"
                width="500px">
                                    <v-card title="Empleo" subtitle="Editar datos del empleo registrado">
                                        <v-card-text>
                                            <v-text-field
                                    label="Nombre del empleo"
                                    type="text"
                                    maxLength="50"
                                    counter
                                    clearable
                                    prepend-icon="mdi-account-tie"
                                    placeholder="Ingrese el nombre del empleo a registrar" 
                                    v-model="datos.nombre">
                                    </v-text-field>
                                    <br>
                                    <v-text-field
                                    label="Ubicación de la empresa"
                                    type="text"
                                    maxLength="50"
                                    counter
                                    clearable
                                    prepend-icon="mdi-map-marker"
                                    placeholder="Ingrese la ubicación de la empresa por favor" 
                                    v-model="datos.ubicacion">
                                    </v-text-field>
                                    <br>
                                    <v-select
                                    label="Categoría del empleo"
                                    placeholder="Selecciona la categoría del empleo"
                                    :items="categorias"
                                    item-value="id"
                                    item-title="nombre"
                                    prepend-icon="mdi-briefcase"
                                    v-model="datos.fk_categoria">
                                    </v-select>
                                    <br>
                                    <v-text-field
                                    label="Pago del empleo"
                                    type="number"
                                    maxLength="10"
                                    counter
                                    clearable
                                    prepend-icon="mdi-cash"
                                    placeholder="Ingrese el monto a pagar por el empleo" 
                                    v-model="datos.pago">
                                    </v-text-field>
                                    <br>
                                    <v-text-field
                                    label="Tiempo de contrato"
                                    type="text"
                                    maxLength="100"
                                    counter
                                    clearable
                                    prepend-icon="mdi-clipboard-clock-outline"
                                    placeholder="Ingrese el tiempo de duración del contrato"
                                    v-model="datos.tiempo_contrato">
                                    </v-text-field>
                                    <br>
                                    <v-text-field
                                    label="Horario laboral"
                                    type="text"
                                    maxLength="50"
                                    counter
                                    clearable
                                    prepend-icon="mdi-clock-outline"
                                    placeholder="Ingrese el horario establecido para el empleo" 
                                    v-model="datos.horario">
                                    </v-text-field>
                                    <br>
                                    <v-textarea
                                    label="Descripción del empleo"
                                    type="text"
                                    maxLength="100"
                                    counter
                                    clearable
                                    prepend-icon=" mdi-text-box"
                                    placeholder="Describa adecuadamente en qué consiste el trabajo" 
                                    v-model="datos.descripcion_empleo">
                                    </v-textarea>
                                    <br>
                                            <v-row>
                                                <v-col cols="6">
                                                    <v-btn
                                                        prepend-icon="mdi-close"
                                                        block
                                                        color="error"
                                                        @click="dialogTwo = false">
                                                        CANCELAR
                                                    </v-btn>
                                                </v-col>
                                                <v-col cols="6">
                                                    <v-btn
                                                        prepend-icon="mdi-account-plus"
                                                         color="blue-darken-4"
                                                        block 
                                                        @click="actualizarEmpleo(datos.id)">
                                                        ACTUALIZAR
                                                    </v-btn>
                                                </v-col>
                                     </v-row>
                                </v-card-text>
                          </v-card>
                </v-dialog>
</template>

<script>
import axios from 'axios'

export default {
    name: 
        'ClienteView',
        data() {
            return {
                categorias: [],
                empleo: {
                    nombre: '',
                            ubicacion: '',
                            fk_categoria: null,
                            pago: null,
                            tiempo_contrato: '',
                            horario: '',
                            descripcion_empleo: ''
                                },
                alertaEstado: false,
                mensaje: '',
                emples : [],
                datos: {},
                dialogOne: false,
                dialogTwo: false
            }
        },
    methods: {
        obtenerCategorias() {
            axios.get('http://127.0.0.1:8000/api/categoria/select')
            .then(
                response=> {
                    if (response.data.code==200)  {
                            let res = response.data;
                            this.categorias= res.data;
                    }
                }
            )
            .catch(error=>console.log('Ha ocurrido un error' + error))
        },
        agregarEmpleo() {
            axios.post('http://127.0.0.1:8000/api/empleo/store', this.empleo)
            .then(
                response=> {
                    if (response.data.code==200) {
                            this.alertaEstado = true;
                            this.mensaje=response.data.data;
                            this.obtenerEmpleos();
                            this.empleo ={nombre: '',
                        ubicacion: '',
                        fk_categoria: null,
                        pago: null,
                        tiempo_contrato: '',
                        horario: '',
                        descripcion_empleo: ''};
                    }
                }
            )
            .catch(error=>console.log('Ha ocurrido un error' + error))
        },
        obtenerEmpleos() {
            this.emples = []
            axios.get('http://127.0.0.1:8000/api/empleo/select')
            .then( 
                response => {
                        if(response.data.code ==200) {
                            let res = response.data;
                            this.emples= res.data;
                        }
                }
            )
            .catch(error=>console.log('Ha ocurrido un error' + error))
        },
        verEmpleo(id,action) {
            axios.get(`http://127.0.0.1:8000/api/empleo/find/${id}`)
            .then (
                response =>  {
                    if(response.data.code==200) {
                    let res = response.data
                    this.datos= res.data;                
                            if (action==1) {
                                this.dialogOne = true;
                            }  else {
                                this.dialogTwo=true;
                            }
                }
                }
            )
            .catch(error=>console.log('Ha ocurrido un error' + error))
        },
        actualizarEmpleo(id) {
                axios.put(`http://127.0.0.1:8000/api/empleo/update/${id}`,this.datos)
                .then(
                    response=> {
                        if(response.data.code==200) {
                            this.alertaEstado = true;
                            this.mensaje=response.data.data;
                            this.dialogTwo=false;
                            this.obtenerEmpleos()
                            
                        }
                    }
                )
                .catch(error=> console.log('Ha ocurrido un error' + error))
        },
        borrarEmpleo(id) {
            axios.delete(`http://127.0.0.1:8000/api/empleo/delete/${id}`)
            .then(
                response=> {
                    if (response.data.code==200) {
                            this.alertaEstado = true;
                            this.mensaje=response.data.data;
                            this.obtenerEmpleos()
                    }
                }
            )
            .catch(error=> console.log('Ha ocurrido un error'+error))
        }
    },
    created() {
        this.obtenerCategorias(),
        this.obtenerEmpleos()
    }
}
</script>
