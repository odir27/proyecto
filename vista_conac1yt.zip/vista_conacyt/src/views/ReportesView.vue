<template>
    <div>
      <h1>Reportes</h1>
      <p>Bienvenido a reportes</p>
    </div>
  </template>
    <script>
    export default {
        name: 'ReportesView'
    }
    </script>