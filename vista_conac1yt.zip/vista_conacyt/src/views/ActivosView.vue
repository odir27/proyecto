<template>
    <div>
      <h1>Activos</h1>
      <p>Bienvenido a activos</p>
    </div>
  </template>
    <script>
    export default {
        name: 'ActivosView'
    }
    </script>