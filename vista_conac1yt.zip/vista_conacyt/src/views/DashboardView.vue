<template>
    <div>
      <h1>Dashboard</h1>
      <p>Bienvenido al dashboard.</p>
    </div>
  </template>
    <script>
    export default {
        name: 'DashboardView'
    }
    </script>