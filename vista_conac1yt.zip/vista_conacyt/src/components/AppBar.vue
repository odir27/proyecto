<template> 
            <v-app-bar app  class=" bg-indigo-darken-4">
                    <!-- Botón para abrir/cerrar el menú-->
            <v-btn @click="$emit('toggle-drawer')">
            <v-icon>mdi-menu</v-icon>
            </v-btn>
                            <v-toolbar-title 
                                class="text-h4 
                                text-lg-center 
                                font-weight-bold">
                                SISTEMA DE INVENTARIO
                            </v-toolbar-title>
        </v-app-bar>
</template>

<script> 
export default {
    name: 'AppBar',
    emits: ["toggle-drawer"], // Define que este componente puede emitir el evento 'toggle-drawer'.
}
</script>